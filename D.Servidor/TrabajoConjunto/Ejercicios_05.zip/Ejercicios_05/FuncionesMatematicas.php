<?php
class FuncionesMatematicas{
    static function segundoGrado($a,$b,$c){
        
    }
}

?>